many thanks to Arthr for making the sprite and being of much use with his experience
the aim of this mod is to add a cool little fighter for the midline
I guess I wanted to just have an odd bomber that acts in the style of
sustained combat midline is known for
I'm somewhat happy with the result.
Obviously balance-wise it won't be perfect. But we tried as hard as we could
to make it non-shattering for vanilla. It's meant to act in synergy with it
rather than being a huge change for the vanilla experience.

The NPC Heron variant utilizes two Warthogs with a singular Sequence bay
I recommend u try that, although obviously the path ahead is clear.
I hope you have fun.
Merry Christmas.