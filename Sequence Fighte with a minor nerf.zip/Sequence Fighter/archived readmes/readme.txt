what's up guys, scarce here

jk, it's me!!!! Randomized Randomizer *hits you with a frying pan*
HEHAHAHAHAHA! *lightning crackles*
I've made this thing... I mean... Arthr helped me... And um... I also begged
people to play it, but only one guy actually did. And they gave me some
advice... And that advice was very useful...
In short:

Gameplay Concept: Randomized Randomizer
Sprite Execution and Gameplay Advisory: Arthr
Testing and Gameplay Advisory: TetraZeta